create table t0(o CHar(0)CHECK(0&O>O));insert into t0
select randomblob(0)-trim(0);
